#include "GrowlDefines.h"

#ifdef __OBJC__
#	include "GrowlApplicationBridge.h"
#endif
#include "GrowlApplicationBridge-Carbon.h"
