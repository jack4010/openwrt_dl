extern void close_whackrecordfile(void);
extern bool openwhackrecordfile(char *file);
extern bool writewhackrecord(char *buf, int buflen);
